<div class="blog-post post-aside">
  <div class="well">
    <small><?php the_author(); ?>@<?php the_date(); ?></small>
    <?php the_content(); ?>
  </div>
</div>
